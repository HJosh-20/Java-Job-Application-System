/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalproject;

/**
 *
 * @author Josh
 */
public class AgentMenu extends Menu {
    @Override
    public void printMe(){
        System.out.println("----FREE AGENT MENU----");
        System.out.println("======================");
        System.out.println("1. Need to add youre personal info?");
        System.out.println("2. Need to see the list of jobs?");
        System.out.println("3. Need to apply for a job?");
        System.out.println("4. Need to accept a job?");
        System.out.println("5. Need to decline a job?");
        System.out.println("6. Exit");
        System.out.println("======================");
        System.out.println("Enter choice: ");
    }
    
}
