/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalproject;
/**
 *
 * @author Josh
 */
public interface Action {
    public void ApplyForJobs();
    public void AcceptJobs();
    public void DeclineJobs();
    public void OfferJobs();
}
