/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalproject;

/**
 *
 * @author Josh
 */
public class Menu {
    public void printMe(){
        System.out.println("---------MENU---------");
        System.out.println("======================");
        System.out.println("1. Free Agents.");
        System.out.println("2. Management/Staff.");
        System.out.println("3. Exit");
        System.out.println("======================");
        System.out.println("Enter choice: ");
    }
}
